
# CIS30 HW3 Make-up Rubric
### 
---
| Description                                             
| ------------------------------------------------------- 
|                                                                                   |
| Fetching module implementation (10)                            |
|                                                                                |
| Jest unit test coverage >=70%  (13)                                                    |
| Passing all unit tests (6)                                                           |
| Correct use of mocking (4)                                                           |
|                                                                             |
| End-to-end test #1 (5)                                                 |
| End-to-end test #2 (5)                                       |
|                                                                                   |
| Github  unit test branch (2.5)                                                        |
| Github  ui test branch (2.5)                                                        |
| Github  end-to-end test branch (2.5)                                                        |
| Github  implementation branch (2.5)                                                    |
| Good branching/merging flow (pull requests) (5)                                                       |
|                                                                                 |
| Modularity (components and JS code) (5)                                                 | 
| No ESLint error (5)                                                 |
| App build successfully (2)                                               |
|                                                                                |
| _Grade is out of 70 points_                               |


