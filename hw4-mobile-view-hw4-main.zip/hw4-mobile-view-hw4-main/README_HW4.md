# HW4 : Guess The Celebrity (Mobile View)

## Instructions:
 
You will create a **React-Native app that implements the “Guess The Celebrity” game.**

In this assignment, we will use the web implementation to create the mobile view of the app.
Since the backend it is not ready, you will store all the data in the ***Async Storage***.


## Setup:

 
- Install Expo CLI and create a rect native app
 Follow the instructions at https://reactnative.dev/docs/environment-setup


This project will use eslint-plugin-react-native.
 
- Install eslint-plugin-react-native
Follow the instructions at https://www.npmjs.com/package/eslint-plugin-react-native.
We are using the Airbnb JavaScript Style.


## HW3 Code:
- Use the tested and refactored code from HW3 in this assignment 
- Do not include the test files 

## App Specifications:
- The user should enter their name (it will be stored along with their score). Your program should validate this as an alphanumeric string. No password is required
- If it is the first time that the username is entered, then it is stored. If it is a returning user, then their previous best score will be retrieved from the database
- Your app should display a picture of a celebrity one at a time and ask the user to guess/pick the celebrity's name. You should provide 4 potential answers with one being the correct one 
- Your app should contain at least 10 celebrities (10 questions) 
- Your app should pick the celebrity randomly (no hardcoding!) 
- Your app should keep track of the user’s score  
- Your app should display three scores while the user is playing the game: the user's current score, the user’s best score, and the app overall best score with the name of the user 
- Your app should store the user names  and the scores inside ***Async Storage***. The scores must be updated correctly!
- Your app should have an option to display the top "k" players (username + scores) sorted by scores descending
- It is okay to keep "k" as a constant. For example, your app could only display the top 10 players 
- Your app should allow the user to delete their information from the app

## Backend Mocking:
- Since we do not have a backend ready during this phase of the software development, we have to mock it
- You will create a JSON file containing all your questions to mock the model
- You will store the users information inside Async storage
- You will write your code as if we had a backend
- You will read the JSON file to retrieve the questions
- You will import the JSON file inside your React-native app
- You will update the code inside the **storage.js** module that we create in hw3 to use async storage instead 

 

## Validation:
- Your code must be clean, readable, and ***ESLint warning-free*** 
- In addition, all your code must be clean, readable, properly indented, and well-structured.


## GitHub:
- You must use a git branching strategy while working on the homework
- See the link below for more details 

## Submission:
- Do **NOT** push `node_modules` to Github/Gradescope or we will have to deduct points off your assignment.
- Do not forget to commit your work to GitHub regularly.
- Only the last push before the due date will be graded.

## Useful links:
- Async Storage info: https://react-native-async-storage.github.io/async-storage/
- Git branching strategy: https://github.com/MicrosoftDocs/azure-devops-docs/blob/main/docs/repos/git/git-branching-guidance.md
- Import JSON file: https://reactgo.com/react-load-json-file/

