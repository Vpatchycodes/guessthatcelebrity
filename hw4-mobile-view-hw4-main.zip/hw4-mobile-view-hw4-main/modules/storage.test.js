//from HW3
const storage =  require('./storage');

//initialize localstorage test
test('init localstorage', ()=> {
  storage.initLocalStorage();
  expect(localStorage.__STORE__['game']).toBe(JSON.stringify([])); // test that the value for game is empty list
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([]));
  expect(Object.keys(localStorage.__STORE__).length).toBe(2);
});

//add new game tests
test('add new game entry to localstorage', () => {
  storage.addGame({name:'test', score:7});
  expect(localStorage.__STORE__['game']).toBe(JSON.stringify([{name:'test', score:7}]));
  });

test('add new game multiple', () => {
    storage.addGame({name:'test', score: 8});
    expect(localStorage.__STORE__['game']).toBe(JSON.stringify([{name:'test', score:7}, {name:'test', score:8}]));
    });

test('exception', () => { 
  let err;
  try{
    storage.addGame({name:'test'});
  }catch(e){
    err = e;
  }

  expect(err).not.toBe(undefined);
  expect(err.message).toBe('insufficient player info');
});

//update best score tests
test('update player best new player', () => {
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([]));
  storage.updateScore('test', 7); 
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:7}]));
  });

test('update player best existing player success', () => {
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:7}]));
  storage.updateScore('test', 8);
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:8}]));
  });

test('update player best existing player fail', () => {
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:8}]));
  storage.updateScore('test', 6); //typically we would add a game entry for this new score, but to simply testing just directly updated the score
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:8}]));
  });

//find overall best score tests
test('find overall best', () => {
  storage.addGame({name:'gog', score:2});
  storage.updateScore('gog', 2);
  storage.addGame({name:'bob', score:10});
  storage.updateScore('bob', 10);
  let best = storage.computeBest();
  expect(best).toBe(10);
  });

// //new way needed!
// test('exception no scores', () => { 
//   let err;
//   try{
//     storage.computeBest();
//   }catch(e){
//     err = e;
//   }

//   expect(err).not.toBe(undefined);
//   expect(err.message).toBe('no scores');
// });

//delete player tests
test('delete player', () => {
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:8},{name:'gog', score:2},{name:'bob', score:10}]));
  expect(localStorage.__STORE__['game']).toBe(JSON.stringify([{name:'test', score:7},{name:'test', score:8},{name:'gog', score:2},{name:'bob', score:10}]));
  storage.deletePlayer('gog');
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:8},{name:'bob', score:10}]));
  expect(localStorage.__STORE__['game']).toBe(JSON.stringify([{name:'test', score:7},{name:'test', score:8},{name:'bob', score:10}])); 
});

test('delete player 2', () => {
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'test', score:8},{name:'bob', score:10}]));
  expect(localStorage.__STORE__['game']).toBe(JSON.stringify([{name:'test', score:7},{name:'test', score:8},{name:'bob', score:10}])); 
  storage.deletePlayer('test');
  expect(localStorage.__STORE__['score']).toBe(JSON.stringify([{name:'bob', score:10}]));
  expect(localStorage.__STORE__['game']).toBe(JSON.stringify([{name:'bob', score:10}])); 
});

test('exception never existed', () => { 
  let err;
  try{
    storage.deletePlayer('man');
  }catch(e){
    err = e;
  }

  expect(err).not.toBe(undefined);
  expect(err.message).toBe('never existed');
});

//find top k score tests
test('exception not enough scores', () => {
  let err;
  try{
    storage.findTop(20);
  }catch(e){
    err = e;
  }
  expect(err).not.toBe(undefined);
  expect(err.message).toBe('insufficient score length');
});