// from HW3
// initialize localstorage entry
function initLocalStorage(){
  if(!localStorage.getItem('game')){
      localStorage.setItem('game', JSON.stringify([]));
  }
  if(!localStorage.getItem('score')){
      localStorage.setItem('score', JSON.stringify([]));
  }
}

// add new player to game
function addGame(player) {
  if(!player.name || !player.score){
    throw new Error('insufficient player info');
  }
  let l = JSON.parse(localStorage.getItem('game'));
  //add player to the list
  l.push(player);
  localStorage.setItem('game', JSON.stringify(l));
}

// update player's best score after adding game entry
function updateScore(n, s){
  //update score
  let l = JSON.parse(localStorage.getItem('score'));
  let inList = false;
  for(let i = 0; i < l.length; i++) {
    let p = l[i];
    if (p.name === n) {
      if (p.score < s) {
          p.score = s;
      }  
      inList = true;
    }
  }
  if(!inList) {
    l.push({name:n, score:s});
  }
  //update score localStorage
  localStorage.setItem('score', JSON.stringify(l));
}

//find overall best score in game
function computeBest() {
  let l = JSON.parse(localStorage.getItem('score'));
  if (l.length === 0) {
    throw new Error('no scores');
  }
  let best = -1;
  for(let i = 0; i < l.length; i++) {
    let p = l[i];
    if (p.score > best) {
      best = p.score;
    }
  }
  return best;
}

//delete player
function deletePlayer(name) {
  //from game
  let l = JSON.parse(localStorage.getItem('game'));
  let isThere = false;
  for(let i = 0; i < l.length; i++) {
    let p = l[i];
    if (p.name === name) {
      l.splice(i, 1);
      i--;
      isThere = true;
    }
  }
  if (!isThere) {
    throw new Error('never existed');
  }
  localStorage.setItem('game', JSON.stringify(l));
  //from score
  let k = JSON.parse(localStorage.getItem('score'));
  for(let i = 0; i < k.length; i++) {
    let p = k[i];
    if (p.name === name) {
      k.splice(i, 1);
      i--;
    }
  }
  localStorage.setItem('score', JSON.stringify(k));
}

//find top k scores
function findTop(k) {
  let l = JSON.parse(localStorage.getItem('score'));
  if (k > l.length) {
    throw new Error('insufficient score length');
  }
  let s = [];
  for(let i = 0; i < l.length; i++) {
    let p = l[i];
    s.push([p.name, p.score]);
  }
  Object.entries(s).sort((a,b) => b[1] - a[1]);
  let t = [];
  for(let o = 0; o < k; o++) {
    t.push(s[o]);
  }
  return t;
}

module.exports = {initLocalStorage, addGame, updateScore, computeBest, deletePlayer, findTop};