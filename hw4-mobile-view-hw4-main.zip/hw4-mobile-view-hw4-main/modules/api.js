//from HW3
import axios from "axios";
const rootURL = '';

async function addPlayer(player){
    if(!player.name || !player.score){
        throw new Error('invalid player');
    }
    try {
        const response = await axios.post(`${rootURL}/login`, {player: `${player.name}`});
        return response.data;
    } catch(err){
        throw err;
    }
};

async function getQuestion() {
    try {
        const response = await axios.get('/questions');
        return response.data;
    } catch(err) {
        throw err;
    }
};

async function deleteScores(player) {
    if(!player.name || !player.score){
        throw new Error('invalid player');
    }
    try {
        const response = await axios.delete('/login', {data: {name: `${player.name}`} });
        return response.data;
    } catch(err) {
        throw err;
    }

}

async function scoreBoard() {
    try {
        const response = await axios.get('/login');
        return response.data;
    } catch(err) {
        throw new Error('scoreboard retrieval failed');
    }
}


module.exports = { addPlayer, getQuestion, deleteScores, scoreBoard };